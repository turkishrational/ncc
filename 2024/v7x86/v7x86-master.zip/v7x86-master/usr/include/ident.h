/* UNIX V7 source code: see /COPYRIGHT or www.tuhs.org for details. */

char myname[] = "research 11/70";
