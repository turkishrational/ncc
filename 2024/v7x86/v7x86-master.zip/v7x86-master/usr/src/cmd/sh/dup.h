/* UNIX V7 source code: see /COPYRIGHT or www.tuhs.org for details. */

#
/*
 *	UNIX shell
 *
 *	S. R. Bourne
 *	Bell Telephone Laboratories
 *
 */

#define DUPFLG 0100
