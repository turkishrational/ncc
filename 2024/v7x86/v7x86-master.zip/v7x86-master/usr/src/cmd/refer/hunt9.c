/* UNIX V7 source code: see /COPYRIGHT or www.tuhs.org for details. */

remote(in, out)
	char *in, *out;
{
/* "in" is a long distance file name: get it */
;
}
