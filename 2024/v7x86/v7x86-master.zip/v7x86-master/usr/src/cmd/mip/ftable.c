/* UNIX V7 source code: see /COPYRIGHT or www.tuhs.org for details. */

# define FORT
# include "table.c"
