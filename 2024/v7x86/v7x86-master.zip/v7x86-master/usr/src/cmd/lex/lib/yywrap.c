/* UNIX V7 source code: see /COPYRIGHT or www.tuhs.org for details. */

yywrap()
{
	return(1);
}
