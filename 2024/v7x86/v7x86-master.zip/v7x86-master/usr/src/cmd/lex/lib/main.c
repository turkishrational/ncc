/* UNIX V7 source code: see /COPYRIGHT or www.tuhs.org for details. */

# include "stdio.h"
main(){
yylex();
exit(0);
}
