## v7x86

This is a fork of v7/x86, designed to maintain and update the operating system.
